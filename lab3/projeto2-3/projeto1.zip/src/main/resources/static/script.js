document.addEventListener('DOMContentLoaded', () => {
    const livrosList = document.getElementById('livros-list');
    const addLivroForm = document.getElementById('add-livro-form');
    const livroNameInput = document.getElementById('livro-name');

    async function fetchLivros() {
        const response = await fetch('/livros');
        const livros = await response.json();
        livrosList.innerHTML = '';
        livros.forEach(livro => {
            const li = document.createElement('li');
            li.textContent = livro.name;
            livrosList.appendChild(li);
        });
    }

    addLivroForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const name = livroNameInput.value;
        if (name) {
            await fetch('/livros', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ name }),
            });
            livroNameInput.value = '';
            fetchLivros();
        }
    });

    fetchLivros();
});
