
package Lab3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import javax.annotation.PostConstruct;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@SpringBootApplication
public class LivrosDemo {

    public static void main(String[] args) {
        SpringApplication.run(LivrosDemo.class, args);
    }
}

@RestController
@RequestMapping("/livros")
class RestApiDemoController {
    private final LivroRepository livroRepository;

    public RestApiDemoController(LivroRepository livroRepository) {
        this.livroRepository = livroRepository;
    }

    @GetMapping
    Iterable<Livros> getLivros() {
        return livroRepository.findAll();
    }

    @GetMapping("/{id}")
    Optional<Livros> getLivrosById(@PathVariable String id) {
        return livroRepository.findById(id);
    }

    @PostMapping
    Livros postLivros(@RequestBody Livros livros) {
        return livroRepository.save(livros);
    }

    @PutMapping("/{id}")
    ResponseEntity<Livros> putLivros(@PathVariable String id,
                                     @RequestBody Livros livros) {

        return (livroRepository.existsById(id))
                ? new ResponseEntity<>(livroRepository.save(livros), HttpStatus.OK)
                : new ResponseEntity<>(livroRepository.save(livros), HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    void deleteLivros(@PathVariable String id) {
        livroRepository.deleteById(id);
    }
}

@Component
class DataLoader {
    private final LivroRepository livroRepository;

    public DataLoader(LivroRepository livroRepository) {
        this.livroRepository = livroRepository;
    }

    @PostConstruct
    private void loadData() {
        livroRepository.saveAll(List.of(
                new Livros("Senhor dos Anéis"),
                new Livros("O Cravo e a Rosa")
        ));
    }
}

interface LivroRepository extends CrudRepository<Livros, String> {
}

@Entity
class Livros {
    @Id
    private final String id;
    private String name;

    public Livros(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public Livros(String name) {
        this(UUID.randomUUID().toString(), name);
    }

    public Livros() {
        this.id = UUID.randomUUID().toString();
        this.name = "";
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}